import { SQSClient } from "@aws-sdk/client-sqs";
export { SendMessageCommand } from "@aws-sdk/client-sqs";

const config = {
    credentials:{
        accessKeyId: process.env.ACCESS_KEY_ID,
        secretAccessKey: process.env.SECRET_ACCESS_KEY
    },
    region: process.env.region
}
export const sqsClient = new SQSClient(config);

